REQUIREMENTS:
Azureus requires Sun Java 1.4.x or newer to run.
JRE 1.5 (5.0 series) is highly recommended.
http://java.sun.com

RUNNING:
1. Extract the contents of this .tar.bz2 file.
2. Change to the 'azureus' directory where the files were extracted.
3. Start Azureus by running the script named 'azureus'; ex. "./azureus"

NOTE:
If you have the Java JRE installed somewhere unusual (or not in your PATH),
use the JAVA_PROGRAM_DIR option in the script.

